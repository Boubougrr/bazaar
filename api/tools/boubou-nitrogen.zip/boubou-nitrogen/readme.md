<p align='center'>
  <b>Follow me here</b><br>  
  <a href="https://discord.gg/unUAtTNNXKeki">Discord</a> |
  <a href="https://www.youtube.com/channel/UC-XII5SSqbMOF1UX3N0Gl8g">YouTube</a> |
  <a href="https://github.com/BouBou-240">Github</a><br><br>
  <img src="https://cdn.discordapp.com/attachments/1513120718458716190/1519244494023819406/ppadivsory.png?ex=6a3cda31&is=6a3b88b1&hm=fb6fcccb4df8e23d4838d5697fb8a1706ead12e09b3a7a4c94ac766bfc9a9e31&" style="width: 60%">
</p>

##  


### ☕ Usage  
- #### 💻 Downloading
     ```
    >> git clone https://github.com/KanekiWeb/Nitro-Generator/new/main
    >> pip install -r requirements.txt
    ```
- #### 🖥️ Starting
      1 - Enter your proxies in config/proxies.txt
      2 - Create Discord Webhook and put link in config/config.json (optional)
      3 - Enter a custom avatar url and username for webhook (optional)
      4 - Select how many thread you want use in config/config.json (optional)
      5 - Run main.py and enjoy checking

##  

### 🏆 Features List
- Very Fast Checking
- Proxy support: http/s, socks4/5, Premium
- Simple Usage
- Custom Thread
- Send hit to webhook

##   

### 🧰 Support
- Email: <phoenix.guecko@gmail.com>
- Discord: htthttps://discord.gg/unUAtTNNXKeki

##  

### 📜 License & Warning
- Make for education propose only
- Under licensed MIT MIT License.

##  

<p align="center">
  <img src="https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat" alt="Contribution Welcome">
  <img src="https://img.shields.io/badge/License-GPLv3-blue.svg" alt="License Badge">
  <img src="https://badges.frapsoft.com/os/v3/open-source.svg?v=103" alt="Open Source">
  <img src="https://visitor-badge.laobi.icu/badge?page_id=KanekiWeb.Nitro-Generator" alt="Visitor Count">
</p>
