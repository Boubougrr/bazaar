# -----------------------------------------------------------------------------------------------

import time
import sys
import os
import subprocess
from colorama import Fore, Style, init
import requests
from bs4 import BeautifulSoup

init(autoreset=True)

# -------------------------------------------------------------------------------------------------

Credits = """
 Discord server: https://discord.gg/XSaxwZkeww

 Discord: boubou.240

 GitHub : https://github.com/BouBou-240

 Developed by boubou
"""

text = """                                                                                                                                                                                                                    
 ( join me on discord : boubou.240 )


------------------------------------------------------------------------------------------------------------------------"""

fonction = """
      +--------------------------------------------------------------------------------------------------------+
      |                                                                                                        |
      |    [1] Search an Onion Site       [2] Download a VPN for Free       [3] Download Tor for Free          |
      |                                                                                                        |
      |    [4] Open Tor on this device    [5] Need Support                  [6] Credits                        | 
      |                                                                                                        |
      +--------------------------------------------------------------------------------------------------------+"""

# -----------------------------------------------------------------------------------------------------

def detect_tor_proxy():
    possible_proxies = [
        {"http": "socks5h://127.0.0.1:9150", "https": "socks5h://127.0.0.1:9150"}, # Tor Browser
        {"http": "socks5h://127.0.0.1:9050", "https": "socks5h://127.0.0.1:9050"}, # Service Tor local
    ]
    for proxy in possible_proxies:
        try:
            test = requests.get("http://check.torproject.org", proxies=proxy, timeout=5)
            if "Congratulations" in test.text:
                return proxy
        except:
            continue
    return None

# -----------------------------------------------------------------------------------------------------

print("")
print(Fore.LIGHTYELLOW_EX + "Version : 1.0                                                                                 ░░░░█▒░░      ")
time.sleep(0.1)
print(Fore.LIGHTYELLOW_EX + "                                                                                             ░░░░█▒░░      ")
time.sleep(0.1)
print(Fore.LIGHTYELLOW_EX + "                                                                                           ▒██▓░ ")
time.sleep(0.1)
print(Fore.LIGHTYELLOW_EX + "                                                                                        ██  ░▓░ ███        ")
time.sleep(0.1)
print(Fore.LIGHTYELLOW_EX + "                                                                                   ██▓   ░▓█░█   ███     ")
time.sleep(0.1)
print(Fore.LIGHTYELLOW_EX + "                                                                                  ██   ░██▒▓█▒░█▓░  ███ ")
time.sleep(0.1)
print(Fore.LIGHTYELLOW_EX + " ████████╗ ██████╗ ██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗        █▒  ░██▒▒░▓█░▓░█▒▓▓░░██ ")
time.sleep(0.1)
print(Fore.LIGHTYELLOW_EX + " ╚══██╔══╝██╔═══██╗██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝       █░ █ ▓█░▒▒░█▓ ▒██▓▓██▓▒█▓")
time.sleep(0.1)
print(Fore.LIGHTYELLOW_EX + "    ██║   ██║   ██║██████╔╝       ██║   ██║   ██║██║   ██║██║     ███████╗       █░ █▓█░░█  █ ▒░█▓█▓▓▓██ ")
time.sleep(0.1)
print(Fore.LIGHTYELLOW_EX + "    ██║   ██║   ██║██╔══██╗       ██║   ██║   ██║██║   ██║██║     ╚════██║         ██  ░░  █ █▒██▓▒▒▓██▒  ")
time.sleep(0.1)
print(Fore.LIGHTYELLOW_EX + "    ██║   ╚██████╔╝██║  ██║       ██║   ╚██████╔╝╚██████╔╝███████╗███████║           ████░▓ ▒ ██▓▒███     ")
time.sleep(0.1)                                                                                                   
print(Fore.LIGHTYELLOW_EX + "    ╚═╝    ╚═════╝ ╚═╝  ╚═╝       ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝              ██████████░         ")
time.sleep(0.1)
print(Fore.LIGHTYELLOW_EX + "                                                                                           ▒██▓░ ")
time.sleep(0.1)
print(Fore.LIGHTYELLOW_EX + text + Style.RESET_ALL)
time.sleep(0.2)

# -------------------------------------------------------------------------------------------------

print(Fore.LIGHTYELLOW_EX + fonction)
print("")
question = input(Fore.LIGHTYELLOW_EX + " Enter a number between 1 and 6 >>> ")
sys.stdout.write("\033[F")
sys.stdout.write("\033[K") 

# -------------------------------------------------------------------------------------------------

if question == "1":
    recherche = input(Fore.LIGHTYELLOW_EX + " [ Please Open Tor Browser ] Enter the name of the site to search >>> ")
    print(Fore.LIGHTCYAN_EX + "\n[Searching...]\n")

    proxies = detect_tor_proxy()
    if proxies is None:
        print(Fore.LIGHTRED_EX + "Error: Tor is not active or the proxy is incorrect !")
        print(Fore.LIGHTRED_EX + "Please launch Tor Browser before continuing.")
        input(Fore.LIGHTYELLOW_EX + "\nPress ENTER to close the menu...")
        sys.exit()

    try:
        url = f"https://onionsearchengine.com/search.php?q={recherche}"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
        }
        response = requests.get(url, headers=headers, proxies=proxies, timeout=10)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, "html.parser")
        results = soup.select("ul.results-list li.result-item")

        if not results:
            print(Fore.LIGHTRED_EX + "No results found.")
        else:
            for result in results:
                titre_tag = result.select_one("h3.result-title a")
                snippet_tag = result.select_one("p.result-snippet")
                titre_text = titre_tag.get_text(strip=True) if titre_tag else "Titre non trouvé"
                lien_text = titre_tag["href"] if titre_tag else "Lien non trouvé"
                snippet_text = snippet_tag.get_text(strip=True) if snippet_tag else ""
                print(Fore.LIGHTBLUE_EX + titre_text)
                print(Fore.LIGHTGREEN_EX + lien_text)
                print(Fore.LIGHTYELLOW_EX + snippet_text)
                print()

    except Exception as e:
        print(Fore.LIGHTRED_EX + f"Error: {e}")

    input(Fore.LIGHTYELLOW_EX + "\nPress ENTER to return to the menu...")
    
# -------------------------------------------------------------------------------------------------
elif question == "2":
    print(Fore.LIGHTGREEN_EX + " Install RiseupVPN for Free : https://riseup.net/fr/vpn")
    time.sleep(0.3)
    input(Fore.LIGHTGREEN_EX + " Press ENTER to close the menu...")
elif question == "3":
    print(Fore.LIGHTGREEN_EX + " Install Tor Browser for Free : https://www.torproject.org/fr/download")
    time.sleep(0.3)
    input(Fore.LIGHTGREEN_EX + " Press ENTER to return to close the menu...")
elif question == "4":
    print(Fore.LIGHTGREEN_EX + "[Error] This option is not yet available...")
    time.sleep(0.3)
    input(Fore.LIGHTGREEN_EX + " Press ENTER to close the menu...")
elif question == "5":
    print(Fore.LIGHTMAGENTA_EX + " Contact me on discord for help : boubou.240")
    time.sleep(0.3)
    input(Fore.LIGHTGREEN_EX + " Press ENTER to return to close the menu...")
    time.sleep(999)
elif question == "6":
    print(Fore.LIGHTYELLOW_EX + "------------------------------------------------------------------------------------------------------------------------")
    print(Fore.YELLOW + Credits)
    time.sleep(0.3)
    input(Fore.LIGHTGREEN_EX + " Press ENTER to return to close the menu...")
else:
    print("")
    time.sleep(0.1)
    print(Fore.LIGHTRED_EX + " [ Error ] Please enter a number between 1 and 6")
    time.sleep(0.2)
    print("")
    time.sleep(0.3)
    input(Fore.LIGHTGREEN_EX + " Press ENTER to close the menu...")

# -------------------------------------------------------------------------------------------------
