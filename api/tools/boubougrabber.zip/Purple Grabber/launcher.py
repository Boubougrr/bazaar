import subprocess
import sys
import time 
import os
import webbrowser

# -----------------------------

try:
    from colorama import Fore, Style, init
except ImportError:
    subprocess.check_call(
    [sys.executable, "-m", "pip", "install", "colorama"],
    stdout=subprocess.DEVNULL,
    stderr=subprocess.DEVNULL
)
    from colorama import Fore, Style, init
    
init()

# -----------------------------

def launch_builder():
    builder_path = os.path.join(os.path.dirname(__file__), "gui", "gui.py")
    if not os.path.exists(builder_path):
        print(Fore.LIGHTMAGENTA_EX + "[PURPLE]" + Fore.LIGHTWHITE_EX + f" builder.py not found at: {builder_path}" + Style.RESET_ALL )
        sys.exit(1)
    print( Fore.LIGHTMAGENTA_EX + "[PURPLE]" + Fore.LIGHTWHITE_EX + " Launching Builder..." + Style.RESET_ALL )
    time.sleep(0.9)
    os.system("cls" if os.name == "nt" else "clear")
    print( Fore.LIGHTMAGENTA_EX + "[PURPLE]" + Fore.LIGHTWHITE_EX + " BUILDER = " + Fore.LIGHTGREEN_EX + "ON" + Style.RESET_ALL )
    subprocess.Popen([sys.executable, builder_path])

# -----------------------------

install = [
    "requests",
    "selenium",
    "discord-webhook",
    "beautifulsoup4",
    "discord",
    "grab",
    "setuptools"
]

# -----------------------------

for package in install:
    print(
    Fore.LIGHTMAGENTA_EX + "[PURPLE]" +
    Fore.LIGHTWHITE_EX   + f" INSTALLING {package}..." +
    Style.RESET_ALL
)
    
# ----------------
    time.sleep(0.6)
# ----------------

    subprocess.check_call(
        [sys.executable, "-m", "pip", "install", package, "-qq"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
)   

    
# -----------------------------

os.system("cls" if os.name == "nt" else "clear")
print( Fore.LIGHTMAGENTA_EX + "[PURPLE]" + Fore.LIGHTWHITE_EX + " All libraries are" + Fore.LIGHTGREEN_EX + " installed." + Style.RESET_ALL)
ok = input(( Fore.LIGHTMAGENTA_EX + "[PURPLE]" + Fore.LIGHTWHITE_EX + " PRESS" + Fore.LIGHTGREEN_EX + " OK " + Fore.LIGHTWHITE_EX + ">>> " + Style.RESET_ALL))

if ok == "OK":
    os.close
    time.sleep(0.3)
elif ok == "ok":
    os.close
    time.sleep(0.3)
elif ok == "Ok":
    os.close
    time.sleep(0.3)
elif ok == "oK":
    os.close
    time.sleep(0.3)
else:
    print( Fore.LIGHTRED_EX + "[ERROR]" + Fore.LIGHTWHITE_EX + " CLOSE..." + Style.RESET_ALL )
    time.sleep(2)

    python_dir = os.path.dirname(sys.executable)
    pythonw = os.path.join(python_dir, "pythonw.exe")
    interpreter = pythonw if os.path.exists(pythonw) else sys.executable

    kwargs = {}
    if os.name == "nt":
        kwargs["creationflags"] = 0x08000000  # CREATE_NO_WINDOW

    subprocess.Popen([interpreter, builder_path], cwd=base, **kwargs)
    
if __name__ == "__main__":
    launch_builder()